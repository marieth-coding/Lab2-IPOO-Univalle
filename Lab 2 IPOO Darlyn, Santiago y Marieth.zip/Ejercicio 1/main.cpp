/**
 * @file main.cpp
 * @brief Programa principal interactivo para la gestion de Muebles Modernos.
 * @details Intencion: capturar el anio actual y los datos de 3 operarios con
 *          reintentos ante datos invalidos, calcular salarios y edades, la nomina
 *          total y reportar el operario de mayor edad.
 *
 * Laboratorio 2 (Agregacion y Composicion), Ejercicio 1: Muebles Modernos.
 * Curso 75003C, Grupo 2. Profesor: Jose Antonio Garcia Mecinas.
 *
 * @author Darlyn Valeria Jurado Burbano (darlyn.jurado@correounivalle.edu.co)
 * @author Santiago Andres Gomez Galvis (santiago.andres.gomez@correounivalle.edu.co)
 * @author Marieth Leguizamo Fajardo (marieth.leguizamo@correounivalle.edu.co)
 * @date 2026-10-28 (creacion)
 * @date 2026-10-28 (ultima modificacion)
 * @version 1.0
 * @copyright Uso academico, Universidad del Valle.
 */

#include "empresa.hpp"
#include <iostream>
#include <iomanip>
#include <limits>
#include <string>

namespace
{
    /**
     * @brief Limpia el estado de error de std::cin y descarta el buffer pendiente.
     */
    void LimpiarBufferEntrada()
    {
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    /**
     * @brief Lee un entero validando que sea mayor que cero con reintento.
     * @param[in] mensaje Texto guia para el usuario.
     * @param[in] mensaje_error Texto de advertencia si el dato no es valido.
     * @return Entero estrictamente positivo.
     */
    int LeerEnteroPositivo(const std::string& mensaje,
                           const std::string& mensaje_error)
    {
        int valor = 0;
        while (true)
        {
            std::cout << mensaje;
            if (std::cin >> valor && valor > 0)
            {
                LimpiarBufferEntrada();
                return valor;
            }
            std::cout << mensaje_error << std::endl;
            LimpiarBufferEntrada();
        }
    }

    /**
     * @brief Lee un entero validando que no sea negativo con reintento.
     * @param[in] mensaje Texto guia para el usuario.
     * @param[in] mensaje_error Texto de advertencia si el dato no es valido.
     * @return Entero mayor o igual a cero.
     */
    int LeerEnteroNoNegativo(const std::string& mensaje,
                             const std::string& mensaje_error)
    {
        int valor = 0;
        while (true)
        {
            std::cout << mensaje;
            if (std::cin >> valor && valor >= 0)
            {
                LimpiarBufferEntrada();
                return valor;
            }
            std::cout << mensaje_error << std::endl;
            LimpiarBufferEntrada();
        }
    }

    /**
     * @brief Lee un numero real validando que no sea negativo con reintento.
     * @param[in] mensaje Texto guia para el usuario.
     * @param[in] mensaje_error Texto de advertencia si el dato no es valido.
     * @return Numero double mayor o igual a cero.
     */
    double LeerDoubleNoNegativo(const std::string& mensaje,
                                const std::string& mensaje_error)
    {
        double valor = 0.0;
        while (true)
        {
            std::cout << mensaje;
            if (std::cin >> valor && valor >= 0.0)
            {
                LimpiarBufferEntrada();
                return valor;
            }
            std::cout << mensaje_error << std::endl;
            LimpiarBufferEntrada();
        }
    }

    /**
     * @brief Lee el anio de nacimiento validando que este en rango [1, anio_actual].
     * @param[in] anio_actual Limite superior admitido.
     * @return Anio de nacimiento valido.
     */
    int LeerAnioNacimiento(int anio_actual)
    {
        int anio_nacimiento = 0;
        while (true)
        {
            std::cout << "Anio de nacimiento: ";
            if (std::cin >> anio_nacimiento &&
                anio_nacimiento > 0 &&
                anio_nacimiento <= anio_actual)
            {
                LimpiarBufferEntrada();
                return anio_nacimiento;
            }
            std::cout << "Error: Anio de nacimiento invalido." << std::endl;
            LimpiarBufferEntrada();
        }
    }

    /**
     * @brief Lee una cadena de texto no vacia desde consola.
     * @param[in] mensaje Texto guia para el usuario.
     * @return Cadena leida con al menos un caracter.
     */
    std::string LeerCadenaNoVacia(const std::string& mensaje)
    {
        std::string texto = "";
        while (true)
        {
            std::cout << mensaje;
            if (std::getline(std::cin, texto) && !texto.empty())
            {
                return texto;
            }
            std::cout << "Error: El campo no puede estar vacio." << std::endl;
        }
    }
}

int main()
{
    std::cout << "========================================" << std::endl;
    std::cout << "   TALLER MUEBLES MODERNOS - NOMINA     " << std::endl;
    std::cout << "========================================" << std::endl;

    int anio_actual = LeerEnteroPositivo(
        "Ingrese el anio actual de operacion: ",
        "Error: Anio actual invalido.");

    Empresa taller("Muebles Modernos", anio_actual);

    for (int i = 0; i < Empresa::TOTAL_EMPLEADOS; ++i)
    {
        std::cout << "\n--- Datos del Empleado #" << (i + 1) << " ---" << std::endl;

        std::string nombre = LeerCadenaNoVacia("Nombre completo: ");
        std::string documento = LeerCadenaNoVacia("Numero de documento: ");
        int anio_nacimiento = LeerAnioNacimiento(anio_actual);
        int antiguedad = LeerEnteroNoNegativo(
            "Antiguedad (en anios): ",
            "Error: La antiguedad no puede ser negativa.");
        double horas = LeerDoubleNoNegativo(
            "Horas trabajadas en el periodo: ",
            "Error: Las horas no pueden ser negativas.");
        double valor_hora = LeerDoubleNoNegativo(
            "Valor de la hora: ",
            "Error: El valor de la hora no puede ser negativo.");

        Empleado nuevo_empleado(nombre, documento, anio_nacimiento,
                                antiguedad, horas, valor_hora);
        taller.AsignarEmpleado(i, nuevo_empleado);
    }

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "\n========================================" << std::endl;
    std::cout << "          REPORTE DE NOMINA             " << std::endl;
    std::cout << "Empresa: " << taller.GetNombre() << std::endl;
    std::cout << "Vigencia: " << taller.GetAnioActual() << std::endl;
    std::cout << "========================================" << std::endl;

    for (int j = 0; j < Empresa::TOTAL_EMPLEADOS; ++j)
    {
        const Empleado& empleado = taller.ObtenerEmpleado(j);
        std::cout << "Empleado: " << empleado.GetNombre()
                  << "\n  Documento   : " << empleado.GetDocumento()
                  << "\n  Nacimiento  : " << empleado.GetAnioNacimiento()
                  << "\n  Antiguedad  : " << empleado.GetAntiguedad() << " anios"
                  << "\n  Horas trab. : " << empleado.GetHorasTrabajadas()
                  << "\n  Tarifa hora : $" << empleado.GetValorHora()
                  << "\n  Edad actual : "
                  << empleado.CalcularEdad(taller.GetAnioActual()) << " anios"
                  << "\n  Salario     : $" << empleado.CalcularSalario()
                  << "\n----------------------------------------" << std::endl;
    }

    std::cout << "Nomina total del periodo: $" << taller.CalcularNominaTotal()
              << std::endl;

    const Empleado& mayor = taller.ObtenerEmpleadoMayorEdad();
    std::cout << "Empleado de mayor edad  : " << mayor.GetNombre()
              << " (" << mayor.CalcularEdad(taller.GetAnioActual()) << " anios)"
              << std::endl;
    std::cout << "========================================" << std::endl;

    return 0;
}